package app;

import vehicles.Car;
import vehicles.ElectricCar;
import vehicles.Vehicle;

public class TestCar {
    public static void main(String[] args) {
        Vehicle car = new Car("Mazda 6", "A123BC190", "Black", 2022);
        Vehicle tesla = new ElectricCar("Tesla Model S", "E999XX77", "White", 2023, 100);

        car.setOwnerName("Иван Иванов");
        car.setInsuranceNumber("INS-12345");

        tesla.setOwnerName("Петр Петров");
        tesla.setInsuranceNumber("INS-54321");

        System.out.println(car);
        System.out.println(tesla);

        System.out.println("\nПолиморфизм:");
        System.out.println(car.getModel() + " — " + car.vehicleType());
        System.out.println(tesla.getModel() + " — " + tesla.vehicleType());
    }
}
